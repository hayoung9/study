package com.example.mysqldb.controller;

import com.example.mysqldb.domain.Board;
import com.example.mysqldb.service.BoardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/board/*")
@RequiredArgsConstructor
public class BoardController {

    private final BoardService boardService;

    @GetMapping("/hello")
    public String Hello() {
        return "boards/hello";
    }

    @GetMapping("/test")
    public String test(Model model) {
        model.addAttribute("cnt", boardService.boardCount());
        model.addAttribute("test", boardService.boardList());
        return "/boards/hello";
    }

    @GetMapping("/main")
    public String main(Model model) {
        model.addAttribute("list", boardService.boardList());
        return "/boards/main";
    }

    @GetMapping("/view")
    public String viewBoard(Model model, int boardId) {
        model.addAttribute("view", boardService.getBoard(boardId));
        return "/boards/view";
    }

    @GetMapping("/insert")
    public String insertForm() {
        return "/boards/insert";
    }

    @PostMapping("/insert")
    public String insertForm(Board board) {
        boardService.uploadBoard(board);
        return "redirect:/board/main";
    }

    @PutMapping("/update")
    public String updateBoard(Board board) {
        boardService.updateBoard(board);
        return "redirect:/board/main";
    }

    @DeleteMapping("/delete")
    public String deleteBoard(int boardId) {
        boardService.deleteBoard(boardId);
        return "redirect:/board/main";
    }
}
