package com.example.mysqldb;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(basePackages = "com.example.mysqldb")
public class MySqlDbApplication {

    public static void main(String[] args) {
        SpringApplication.run(MySqlDbApplication.class, args);
    }

}
