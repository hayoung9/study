package com.example.mysqldb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySqlDbApplicationTests {

    @Test
    void contextLoads() {
    }

}
