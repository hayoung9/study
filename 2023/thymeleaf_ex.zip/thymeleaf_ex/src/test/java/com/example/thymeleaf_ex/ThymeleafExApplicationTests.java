package com.example.thymeleaf_ex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeleafExApplicationTests {

    @Test
    void contextLoads() {
    }

}
